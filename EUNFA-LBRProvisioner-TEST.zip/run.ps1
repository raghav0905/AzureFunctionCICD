$in = Get-Content $triggerInput -Raw
Write-Output "PowerShell script processed queue message '$in'"

#Main Function
try {
    $InputArray = $in.Split(';')

    $Owner = $InputArray[2]

    $TemplateTypevalue = $InputArray[3]

    #Data from LBR Store Links item
    $StoreLinkItemID = [int]$InputArray[0]  
    $StoreLinkItemName = $InputArray[1]

    #MSI Variables via Function Application Settings Variables
    $endpoint = $env:MSI_ENDPOINT
    $secret = $env:MSI_SECRET

    $LBR_SITETEMPLATESPATH = $env:LBR_FUNCTIONROOTPATH + $env:LBR_SITETEMPLATESFOLDERTITLE 

    # Connecting to your tenant 

    # Capturing TraceLog 
    Set-TraceLog -FilePath $env:LOGPATH -FileName $env:LOGNAME -Level $env:LOGLEVEL -Status $env:LOGSTATUS

    #Getting Client Id from Vault
    $clientId = Get-SecretsFromKeyVault -vaultURI $env:CLIENTIDVAULTURI -endPoint $endpoint -secret $secret

    #Getting Certificate from Vault
    $certificate = Get-SecretsFromKeyVault -vaultURI $env:CERTIFICATEVAULTURI -endPoint $endpoint -secret $secret

    #Getting Certificate Key from Vault
    $key = Get-SecretsFromKeyVault -vaultURI $env:CERTIFICATEKEYVAULTURI -endPoint $endpoint -secret $secret

    #Padding zeroes 
    if ($StoreLinkItemID -lt 10) {
        $SiteNaming = "00" + [string]$StoreLinkItemID
    }
    elseif (($StoreLinkItemID -lt 100) -and ($StoreLinkItemID -gt 9)) {
        $SiteNaming = "0" + [string]$StoreLinkItemID
    }
    else {
        $SiteNaming = [string]$StoreLinkItemID 
    }

    $SiteURL = $env:TENANTABSOLUTEURL + "/sites/LBR-" + $SiteNaming
    
    $msg = "Creating Site -  " + $SiteURL + "      ID : " + $SiteNaming
    Write-Output $msg

    Connect-Site -siteUrl $env:LBR_HUBSITEURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN
    Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values @{"ProvisionStatus" = "InProgress"; "SiteProvisionStatus" = "In Progress" }
    Disconnect-PnPOnline        

    # Creating the Modern Site
    Write-Output "Connecting Admin Site..."
    #Calling Connect-Site to create a connection to Destination site
    Connect-Site -siteUrl $env:TENANTURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN

    Write-Output "Creating Site..."
    $ProcessError = Create-SiteWithoutO365Group -StoreLinkItemName $StoreLinkItemName -SiteURL $SiteURL -Owner $Owner
    Disconnect-PnPOnline

    Connect-Site -siteUrl $env:LBR_HUBSITEURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN

    #-------------------------------PROVISIONING---------------------------------#
    if ($ProcessError) {
        Write-Output $ProcessError

        $URLValue = New-Object Microsoft.SharePoint.Client.FieldUrlValue   
        $URLValue.Url = $SiteURL;  
        $URLValue.Description = $StoreLinkItemName;  
        $values = @{"URL" = [Microsoft.SharePoint.Client.FieldUrlValue]$URLValue } 

        Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values $values
    }
    else {
        $URLValue = New-Object Microsoft.SharePoint.Client.FieldUrlValue   
        $URLValue.Url = $SiteURL;  
        $URLValue.Description = $StoreLinkItemName;  
        $values = @{"URL" = [Microsoft.SharePoint.Client.FieldUrlValue]$URLValue } 
        Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values $values
    }
    Disconnect-PnPOnline  
    
    #Calling Connect-Site to create a connection to Destination site
    Connect-Site -siteUrl $SiteURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN

    #Validate the URL for newly created site
    Get-PnPWeb -ErrorAction SilentlyContinue -ErrorVariable ProcessError   

    if ($ProcessError) {
        Write-Output "The URL of Site Provisioned is not valid"   
        Connect-Site -siteUrl $env:LBR_HUBSITEURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN
        Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values @{ "ProvisionStatus" = "Failure"; "SiteProvisionStatus" = "No" }
        Disconnect-PnPOnline   
    }
    else {
        
        if($TemplateTypevalue -eq $env:TEMPLATENAMEBRANDSTORE){
            $ProvisioningTemplate = $env:LBR_TemplateName + '_' + $env:TEMPLATENAMEBRANDSTORE + '.xml'
        } else {
            $ProvisioningTemplate = $env:LBR_TemplateName + '_' + $env:TEMPLATENAMEFLAGSHIP + '.xml'
        }
        Write-Output $ProvisioningTemplate
        #Calling Apply-SPOProvisioningTemplate to apply XML Template to destination site
        Apply-SPOProvisioningTemplate -siteTemplateName $ProvisioningTemplate  -siteTemplatePath $LBR_SITETEMPLATESPATH

        #Removing the recent navigation node from the quick launch
        Remove-PnPNavigationNode -Title Recent -Location QuickLaunch -Force

        #Calling Disconnect-PnPOnline to dispose connection with destination site
        Disconnect-PnPOnline

        $msg = "Site Provisioned after applying the template, now associating with Hub Site"
        Write-Output $msg 

        #Calling Connect-Site to create a connection to tenant site
        Connect-Site -siteUrl $env:TENANTURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN

        #Calling Associate-ToSPOHubSite to associate destination site to Vendor Collaboration Hub Site
        Associate-ToSPOHubSite -siteUrl $SiteURL -hubSiteUrl $env:LBR_HUBSITEURL

        #Calling Disconnect-PnPOnline to dispose connection
        Disconnect-PnPOnline
        
        #-------------------------------COPY LIST ITEMS---------------------------------#
        CopyLists -templateType $TemplateTypevalue -sourceSiteURL $env:LBR_HUBSITEURL -destinationSiteURL $SiteURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN
        
        $msg = "Data for lists has been copied"
        Write-Output $msg
        Connect-Site -siteUrl $env:LBR_HUBSITEURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN
        Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values @{ "ProvisionStatus" = "Success" ; "SiteProvisionStatus" = "Yes" }
        Disconnect-PnPOnline
    }
}
catch {
    Write-Output $_.Exception.Message
    $msg = "Error - " + $_.Exception.Message
    Connect-Site -siteUrl $env:LBR_HUBSITEURL -clientId $clientId -certificate $certificate -key $key -domain $env:DOMAIN
    Set-PnPListItem -Identity $StoreLinkItemID -List $env:LISTNAMESTORELINKS -Values @{ "ProvisionStatus" = "Failure"; "SiteProvisionStatus" = "No" }
    Disconnect-PnPOnline 
}
